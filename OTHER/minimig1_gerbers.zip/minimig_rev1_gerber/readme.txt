The PCB for Minimig rev1.0 is a two-layer PCB.
The bottom layer is used mainly as a ground plane. The top layer is used as a signal plane.
Because there are no seperate power planes, all large IC's have a small local powerplane in the top layer. This local plane is coupled tightly to the global gnd using LOTS of capacitors. This way, only 2 layers are needed. Almost all decoupling capacitors are mounted at the bottom side of the board.

layers from top to bottom

TSK - silkscreen
TMK - top solder mask
TOP - top copper
BOT - bottom copper
BMK - bottom mask

All gerber files have embedded apertures so there are no seperate aperture files.
NCD is the N/C drill file.

Also, please beware of the PATCH needed to get this board to run. You have to cut a trace running from pin 15 of the PIC to pin81 of the FPGA. Then you have to solder a wire running from pin15 of the PIC to pin9 of header J9. See schematic and included picture.

